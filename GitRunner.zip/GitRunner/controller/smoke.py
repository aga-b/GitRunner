"""Real Docker integration probe, no GitHub runner registration or workflow."""
import os
import time
import uuid
from docker_host import Docker


def main():
    docker= Docker()
    slot='ci-preflight-'+uuid.uuid4().hex[:8]
    labels={'pool':slot, 'slot':slot}
    network=slot+'-net'
    try:
        docker.call('network','create',*docker.labels(labels),network)
        daemon=docker.call('run','-d','--name',slot+'-docker','--network',network,
                          '--privileged','--memory','2g','--memory-swap','2g','--cpus','1',
                          '--env','DOCKER_TLS_CERTDIR=',*docker.labels(labels),
                          os.environ['DIND_IMAGE'],'dockerd','--host=unix:///var/run/docker.sock',
                          '--host=tcp://127.0.0.1:2375','--tls=false')
        ready=False
        for _ in range(30):
            try:
                docker.call('exec',daemon,'docker','info',timeout=5)
                ready=True
                break
            except Exception: time.sleep(1)
        if not ready: raise RuntimeError('Docker-in-Docker startup failed')
        # Probe an actual PostgreSQL service reachable through runner localhost,
        # Docker CLI/compose/buildx and runner's setup-node tool-cache path.
        command='''set -euo pipefail
docker compose version
docker buildx version
test -w /opt/hostedtoolcache
sudo -n true
docker run -d --name pg -e POSTGRES_PASSWORD=ci-test-only -p 5432:5432 postgres:17-alpine
for i in {1..60}; do
  if docker exec pg pg_isready -U postgres >/dev/null 2>&1; then break; fi
  sleep 1
done
python3 -c "import socket; s=socket.create_connection(('127.0.0.1',5432),timeout=10); s.close()"
docker exec pg pg_isready -U postgres
echo 'Docker and localhost PostgreSQL smoke test passed'
'''
        result=docker.call('run','--rm','--name',slot+'-probe','--network','container:'+daemon,
                          '--env','DOCKER_HOST=tcp://127.0.0.1:2375','--entrypoint','bash',
                          *docker.labels(labels), os.environ['RUNNER_IMAGE'],'-c',command,timeout=300)
        print(result)
    finally:
        docker.remove_slot(slot,slot)


if __name__ == '__main__': main()

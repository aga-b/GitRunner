#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "${BASH_SOURCE[0]}")/.."
docker compose ps
docker compose exec -T controller python -c 'from pathlib import Path; print(Path("/state/status.json").read_text())'

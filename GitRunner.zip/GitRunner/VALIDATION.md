# Doğrulama kaydı — 13 Ekim 2026

| Kontrol | Sonuç |
|---|---|
| Python unittest davranış testleri | 24/24 geçti |
| Python compileall (controller/scripts) | Geçti |
| Bütün shell scriptleri için bash -n | Geçti |
| Compose ve smoke workflow YAML parse kontrolü | Geçti |
| Yerel dokümantasyonda repo-özel ad taraması | Eşleşme yok |
| Canlı autoscaler kurulumu | Tamamlandı |
| Geçici runner provisioning/retirement | Canlı loglarda doğrulandı |
| Self-hosted CI işi | En az bir iş tamamlandı |
| Paralel kapasite | 2 runner oluşturuldu |
| Yeni runner image build | `postgresql-client` değişikliğinden sonra hedef hostta bekliyor |
| `apt-get`, `sudo`, `psql` image kontrolü | Dockerfile build-time kontrolü eklendi; canlı build bekliyor |

Mock testleri yeni image'ın gerçek Docker/GitHub execution sonucunun yerine
geçmez. Canlı regresyon `scripts/preflight.sh` ve ardından
`examples/runner-smoke.yml` ile tamamlanmalıdır.
